#include <iostream>
#include "Vect.h"

using namespace std;

int main()
{
	// Vect V2 = vect_construct(10, 2);
	
	// cout << "The array size: " << V2.size << endl;
	// cout << "The array capacity: " << V2.capacity << endl;
	// for (int i = 0; i < 10; i++){
	// 	cout << V2.arr[i] << endl;
	// }
	return 0;
}	