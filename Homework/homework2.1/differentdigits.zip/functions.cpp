#include <iostream>
#include "functions.h"
using namespace std;

int countDigitOccurrences(int n, int digit){

  int howManyTimes = 0;
  int number;
  int one;
  int ten;
  int hundred;
  int thousand;
  int tthousand;

  one = n % 10;
  number = n / 10;
  // cout << "One: " << one << endl;
  // cout << "Number after one: " << number << endl;

  ten = number % 10;
  number = number / 10;
  // cout << "Ten: " << ten << endl;
  // cout << "Number after ten: " << number << endl;

  hundred = number % 10;
  number = number / 10;
  // cout << "Hundred: " << hundred << endl;
  // cout << "Number after hundred: " << number << endl;

  thousand = number % 10000;
  number = number / 10;

  tthousand = number;

  // cout << "Thousand: " << thousand << endl;
  // cout << "Number after thousand: " << number << endl;
  // cout << "TThousand: " << tthousand << endl;

  if (one == digit){
    howManyTimes ++;
  }
  if (ten == digit){
    howManyTimes ++;
  }
  if (hundred == digit){
    howManyTimes ++;
  }
  if (thousand == digit){
    howManyTimes ++;
  }
  if (tthousand == digit){
    howManyTimes ++;
  }


  return howManyTimes;
}
