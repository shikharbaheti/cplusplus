#include <iostream>
#include "functions.h"
using namespace std;

int countDigitOccurrences (int n, int digit) {
  int ones = 0;
  int tens = 0;
  int huns = 0;
  int thous = 0;
  int tthous = 0;
  int numOfTimes = 0;
  int number;

if (n < 10) {
  ones = n;
  //number = n / 10;
} else if (n < 100){
  ones = n % 10;
  number = n / 10;

  tens = number % 10;
  //number = number / 10;
}
else if (n < 1000){
  ones = n % 10;
  number = n / 10;

  tens = number % 10;
  number = number / 10;

  huns = number % 10;
  //number = number / 10;
}
else if (n < 10000){
  ones = n % 10;
  number = n / 10;

  tens = number % 10;
  number = number / 10;

  huns = number % 10;
  number = number / 10;

  thous = number % 10;
  number = number / 10;

  tthous = number % 10;
}

if (ones == digit){
  numOfTimes++;
}
if (tens == digit){
  numOfTimes++;
}
if (huns == digit){
  numOfTimes++;
}
if (thous == digit){
  numOfTimes++;
}
if (tthous == digit){
  numOfTimes++;
}

return numOfTimes;
}
