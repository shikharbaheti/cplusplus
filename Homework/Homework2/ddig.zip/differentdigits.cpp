#include <iostream>
#include "functions.h"
using namespace std;

int main(){

  int aNumber;
  int bNumber;
  int howManyNums;

  cin >> aNumber;
  cin >> bNumber;

  // cout << countDigitOccurrences(3738, 0);

  if (aNumber > 0 && bNumber >= aNumber && bNumber <= 10000){
    for (int i = aNumber; i <= bNumber; i++){
      for (int q = 0; q <= 9; q++) {
        if (countDigitOccurrences(i, q) == 0) {
        howManyNums++;
        }
      }
    }
cout << howManyNums;
return 0;
  }
}
