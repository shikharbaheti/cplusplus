#ifndef MY_HEADER
#define MY_HEADER
int countDigitOccurrences (int, int);
#endif
