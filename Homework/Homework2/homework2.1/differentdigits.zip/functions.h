int countDigitOccurrences (int, int);
